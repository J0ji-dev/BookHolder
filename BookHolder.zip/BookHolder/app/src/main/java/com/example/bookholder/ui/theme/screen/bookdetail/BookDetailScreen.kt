package com.example.bookholder.ui.theme.screen.bookdetail

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun BookDetailScreen(
    bookId: String,
    onNavigateToEditProgress: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "📖 Detalhes do Livro",
            style = androidx.compose.material3.MaterialTheme.typography.headlineMedium
        )

        Text("ID do Livro: $bookId", modifier = Modifier.padding(vertical = 8.dp))

        Button(
            onClick = { onNavigateToEditProgress(bookId) },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("✏️ Editar Progresso")
        }

        Button(
            onClick = onNavigateBack,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("⬅️ Voltar")
        }

        Text(
            "Informações do livro aparecerão aqui...",
            modifier = Modifier.padding(vertical = 16.dp)
        )
    }
}

@Preview
@Composable
fun BookDetailScreenPreview() {
    BookDetailScreen(
        bookId = "test-123",
        onNavigateToEditProgress = {},
        onNavigateBack = {}
    )
}