package com.example.bookholder.ui.theme.screen.editprogress

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun EditProgressScreen(
    bookId: String,
    onNavigateBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "📊 Editar Progresso",
            style = androidx.compose.material3.MaterialTheme.typography.headlineMedium
        )

        Text("Editando progresso do livro: $bookId", modifier = Modifier.padding(vertical = 8.dp))

        Text(
            "Formulário de progresso aparecerá aqui...",
            modifier = Modifier.padding(vertical = 16.dp)
        )

        Button(
            onClick = { /* Salvar progresso */ },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("💾 Salvar Progresso")
        }

        Button(
            onClick = onNavigateBack,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("⬅️ Voltar")
        }
    }
}

@Preview
@Composable
fun EditProgressScreenPreview() {
    EditProgressScreen(
        bookId = "test-123",
        onNavigateBack = {}
    )
}