package com.example.bookholder.data.remote

import retrofit2.Response

sealed class NetworkResult<out T> {
    data class Success<T>(val data: T): NetworkResult<T>()
    data class HttpError(val code: Int, val message: String?): NetworkResult<Nothing>()
    data class NetworkFailure(val throwable: Throwable): NetworkResult<Nothing>()
}

suspend inline fun <T> safeApiCall(crossinline block: suspend () -> T): NetworkResult<T> {
    return try {
        val data = block()
        NetworkResult.Success(data)
    } catch (e: retrofit2.HttpException) {
        NetworkResult.HttpError(e.code(), e.message())
    } catch (t: Throwable) {
        NetworkResult.NetworkFailure(t)
    }
}

suspend inline fun <T> safeApiResponse(crossinline block: suspend () -> Response<T>): NetworkResult<T> {
    return try {
        val response = block()
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null) {
                NetworkResult.Success(body)
            } else {
                NetworkResult.HttpError(response.code(), "Corpo nulo")
            }
        } else {
            NetworkResult.HttpError(response.code(), response.errorBody()?.string())
        }
    } catch (t: Throwable) {
        NetworkResult.NetworkFailure(t)
    }
}
