package com.example.bookholder.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.bookholder.ui.screen.library.LibraryScreen
import com.example.bookholder.ui.theme.screen.home.HomeScreen
import com.example.bookholder.ui.theme.screen.search.SearchScreen
import com.example.bookholder.ui.theme.screen.bookdetail.BookDetailScreen
import com.example.bookholder.ui.theme.screen.editprogress.EditProgressScreen
import com.example.bookholder.ui.theme.screen.stats.StatsScreen
import com.example.bookholder.ui.theme.screen.splash.SplashScreen

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Home : Screen("home")
    object Search : Screen("search")
    object Library : Screen("library")
    object Stats : Screen("stats")
    object BookDetail : Screen("bookDetail/{bookId}") {
        fun createRoute(bookId: String) = "bookDetail/$bookId"
    }
    object EditProgress : Screen("editProgress/{bookId}") {
        fun createRoute(bookId: String) = "editProgress/$bookId"
    }
}

fun NavGraphBuilder.appGraph(
    onNavigateToHome: () -> Unit,
    onNavigateToSearch: () -> Unit,
    onNavigateToLibrary: () -> Unit,
    onNavigateToStats: () -> Unit,
    onNavigateToBookDetail: (String) -> Unit,
    onNavigateToEditProgress: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    composable(Screen.Splash.route) {
        SplashScreen(onNavigateToHome = onNavigateToHome)
    }

    composable(Screen.Home.route) {
        HomeScreen(
            onNavigateToSearch = onNavigateToSearch,
            onNavigateToLibrary = onNavigateToLibrary,
            onNavigateToStats = onNavigateToStats
        )
    }

    composable(Screen.Search.route) {
        SearchScreen(
            onNavigateToBookDetail = onNavigateToBookDetail,
            onNavigateBack = onNavigateBack
        )
    }

    composable(Screen.Library.route) {
        LibraryScreen(
            onNavigateToBookDetail = onNavigateToBookDetail,
            onNavigateBack = onNavigateBack
        )
    }

    composable(Screen.Stats.route) {
        StatsScreen(
            onNavigateBack = onNavigateBack
        )
    }

    composable(
        route = Screen.BookDetail.route,
        arguments = listOf(navArgument("bookId") { })
    ) { backStackEntry ->
        val bookId = backStackEntry.arguments?.getString("bookId") ?: ""
        BookDetailScreen(
            bookId = bookId,
            onNavigateToEditProgress = onNavigateToEditProgress,
            onNavigateBack = onNavigateBack
        )
    }

    composable(
        route = Screen.EditProgress.route,
        arguments = listOf(navArgument("bookId") { })
    ) { backStackEntry ->
        val bookId = backStackEntry.arguments?.getString("bookId") ?: ""
        EditProgressScreen(
            bookId = bookId,
            onNavigateBack = onNavigateBack
        )
    }
}