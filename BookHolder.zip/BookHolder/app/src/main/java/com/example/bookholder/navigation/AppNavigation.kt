package com.example.bookholder.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.NavType
import androidx.navigation.navArgument
import androidx.navigation.compose.rememberNavController
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.bookholder.ui.screen.home.HomeScreen
import com.example.bookholder.ui.screen.search.SearchScreen
import com.example.bookholder.ui.screen.library.LibraryScreen
import com.example.bookholder.ui.screen.bookdetail.BookDetailScreen
import com.example.bookholder.ui.screen.editprogress.EditProgressScreen
import com.example.bookholder.ui.screen.stats.StatsScreen
import com.example.bookholder.ui.screen.splash.SplashScreen

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Home : Screen("home")
    object Search : Screen("search")
    object Library : Screen("library")
    object Stats : Screen("stats")
    object BookDetail : Screen("bookDetail/{bookId}") {
        fun createRoute(bookId: String) = "bookDetail/$bookId"
    }
    object EditProgress : Screen("editProgress/{bookId}") {
        fun createRoute(bookId: String) = "editProgress/$bookId"
    }
}

fun NavGraphBuilder.appGraph() {
    composable(Screen.Splash.route) {
        SplashScreen()
    }

    composable(Screen.Home.route) {
        HomeScreen()
    }

    composable(Screen.Search.route) {
        SearchScreen()
    }

    composable(Screen.Library.route) {
        LibraryScreen()
    }

    composable(Screen.Stats.route) {
        StatsScreen()
    }

    composable(
        route = Screen.BookDetail.route,
        arguments = listOf(navArgument("bookId") { type = NavType.StringType })
    ) { backStackEntry ->
        val bookId = backStackEntry.arguments?.getString("bookId") ?: ""
        BookDetailScreen(bookId = bookId)
    }

    composable(
        route = Screen.EditProgress.route,
        arguments = listOf(navArgument("bookId") { type = NavType.StringType })
    ) { backStackEntry ->
        val bookId = backStackEntry.arguments?.getString("bookId") ?: ""
        EditProgressScreen(bookId = bookId)
    }
}