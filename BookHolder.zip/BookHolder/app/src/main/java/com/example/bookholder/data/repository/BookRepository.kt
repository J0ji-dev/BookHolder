package com.example.bookholder.data.repository

import com.example.bookholder.data.local.BookDatabase
import com.example.bookholder.data.local.entities.Book
import com.example.bookholder.data.local.entities.BookStatus
import com.example.bookholder.data.local.entities.UserBook
import com.example.bookholder.data.remote.NetworkResult
import com.example.bookholder.data.remote.RemoteDataSource
import kotlinx.coroutines.flow.Flow

class BookRepository(
    private val database: BookDatabase,
    private val remote: RemoteDataSource
) {

    // === OPERAÇÕES BOOK ===
    suspend fun insertBook(book: Book) {
        database.bookDao().insertBook(book)
    }

    suspend fun getBook(bookId: String): Book? {
        return database.bookDao().getBook(bookId)
    }

    suspend fun deleteBook(bookId: String) {
        database.bookDao().deleteBook(bookId)
    }

    // === OPERAÇÕES USERBOOK ===
    suspend fun insertUserBook(userBook: UserBook): Long {
        return database.userBookDao().insertUserBook(userBook)
    }

    suspend fun updateUserBook(userBook: UserBook) {
        database.userBookDao().updateUserBook(userBook)
    }

    suspend fun deleteUserBook(userBookId: Long) {
        database.userBookDao().deleteUserBook(userBookId)
    }

    fun getAllUserBooks(): Flow<List<UserBook>> {
        return database.userBookDao().getAllUserBooks()
    }

    fun getBooksByStatus(status: BookStatus): Flow<List<UserBook>> {
        return database.userBookDao().getBooksByStatus(status)
    }

    // === Busca remota no Google Books ===
    // Mantive a assinatura pedida originalmente (List<String>), mapeando para títulos.
    suspend fun searchBooks(query: String): List<String> {
        return when (val result = remote.searchBooks(query)) {
            is NetworkResult.Success -> {
                val items = result.data.items ?: emptyList()
                items.mapNotNull { it.volumeInfo?.title }
            }
            is NetworkResult.HttpError -> emptyList()
            is NetworkResult.NetworkFailure -> emptyList()
        }
    }

    // === JsonPlaceholder (exemplo de uso do service REST) ===
    suspend fun createPost(post: Map<String, Any>): NetworkResult<Map<String, Any>> {
        return remote.createPost(post)
    }

    suspend fun updatePost(id: String, post: Map<String, Any>): NetworkResult<Map<String, Any>> {
        return remote.updatePost(id, post)
    }

    suspend fun deletePost(id: String): NetworkResult<Unit> {
        return remote.deletePost(id)
    }

    // === DADOS MOCK PARA TESTE (mantive, se quiser remover, pode) ===
    suspend fun addSampleBooks() {
        val book1 = Book(
            id = "book1",
            title = "Dom Casmurro",
            authors = "Machado de Assis",
            description = "Romance clássico brasileiro",
            thumbnailUrl = null,
            pageCount = 256,
            publishedDate = "1899",
            publisher = "Editora A",
            isbn = null
        )
        val book2 = Book(
            id = "book2",
            title = "1984",
            authors = "George Orwell",
            description = "Distopia clássica",
            thumbnailUrl = null,
            pageCount = 328,
            publishedDate = "1949",
            publisher = "Editora B",
            isbn = null
        )

        insertBook(book1)
        insertBook(book2)

        val userBook1 = UserBook(
            userBookId = 0L,
            bookId = "book1",
            addedDate = System.currentTimeMillis(),
            status = BookStatus.FINISHED,
            currentPage = 256,
            rating = 4.5f
        )
        val userBook2 = UserBook(
            userBookId = 0L,
            bookId = "book2",
            addedDate = System.currentTimeMillis(),
            status = BookStatus.READING,
            currentPage = 150
        )

        insertUserBook(userBook1)
        insertUserBook(userBook2)
    }
}
