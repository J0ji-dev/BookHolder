package com.example.bookholder.data.repository

import com.example.bookholder.data.local.BookDatabase
import com.example.bookholder.data.local.entities.Book
import com.example.bookholder.data.local.entities.BookStatus
import com.example.bookholder.data.local.entities.UserBook
import com.example.bookholder.data.remote.RetrofitClient
import com.example.bookholder.data.remote.models.BookItem
import kotlinx.coroutines.flow.Flow
import java.util.Date

class BookRepository(private val database: BookDatabase) {

    private val booksApiService = RetrofitClient.booksApiService
    private val jsonPlaceholderService = RetrofitClient.jsonPlaceholderService

    // Room Database operations
    suspend fun insertBook(book: Book) {
        database.bookDao().insertBook(book)
    }

    suspend fun getUserBook(bookId: String): UserBook? {
        return database.userBookDao().getUserBook(bookId)
    }

    suspend fun insertUserBook(userBook: UserBook): Long {
        return database.userBookDao().insertUserBook(userBook)
    }

    suspend fun updateUserBook(userBook: UserBook) {
        database.userBookDao().updateUserBook(userBook)
    }

    fun getUserBooksByStatus(status: BookStatus): Flow<List<UserBook>> {
        return database.userBookDao().getBooksByStatus(status)
    }

    fun getAllUserBooks(): Flow<List<UserBook>> {
        return database.userBookDao().getAllUserBooks()
    }

    // API Operations
    suspend fun searchBooks(query: String): List<BookItem> {
        val response = booksApiService.searchBooks(query)
        return response.items ?: emptyList()
    }

    // Simulated API operations for demonstration
    suspend fun simulateAddBookToLibrary(book: Book): Boolean {
        return try {
            val postData = mapOf(
                "title" to book.title,
                "action" to "add_to_library",
                "timestamp" to Date().time
            )
            val response = jsonPlaceholderService.createPost(postData)
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    suspend fun simulateUpdateReadingProgress(bookId: String, currentPage: Int): Boolean {
        return try {
            val postData = mapOf(
                "bookId" to bookId,
                "currentPage" to currentPage,
                "action" to "update_progress",
                "timestamp" to Date().time
            )
            val response = jsonPlaceholderService.updatePost("1", postData)
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    suspend fun simulateRemoveBookFromLibrary(bookId: String): Boolean {
        return try {
            val response = jsonPlaceholderService.deletePost("1")
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }
}