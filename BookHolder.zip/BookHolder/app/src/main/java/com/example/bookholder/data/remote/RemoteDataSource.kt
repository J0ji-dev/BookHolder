package com.example.bookholder.data.remote

import com.example.bookholder.data.remote.api.BooksApiService
import com.example.bookholder.data.remote.api.JsonPlaceholderService
import com.example.bookholder.data.remote.models.BooksResponse

/**
 * IMPORTANTE:
 * - Este arquivo usa NetworkResult, safeApiCall e safeApiResponse que DEVEM
 *   estar definidos em outro arquivo (ex.: SafeApi.kt) **neste mesmo pacote**
 *   com.example.bookholder.data.remote.
 * - NÃO redefina NetworkResult aqui para evitar "Redeclaration".
 */
class RemoteDataSource(
    private val booksApi: BooksApiService,
    private val jsonService: JsonPlaceholderService
) {

    suspend fun searchBooks(
        query: String,
        maxResults: Int = 20,
        startIndex: Int = 0
    ): NetworkResult<BooksResponse> {
        return safeApiCall {
            booksApi.searchBooks(
                query = query,
                maxResults = maxResults,
                startIndex = startIndex
            )
        }
    }

    suspend fun createPost(post: Map<String, Any>): NetworkResult<Map<String, Any>> {
        return safeApiResponse { jsonService.createPost(post) }
    }

    suspend fun updatePost(id: String, post: Map<String, Any>): NetworkResult<Map<String, Any>> {
        return safeApiResponse { jsonService.updatePost(id, post) }
    }

    suspend fun deletePost(id: String): NetworkResult<Unit> {
        return safeApiResponse { jsonService.deletePost(id) }
    }
}
