package com.example.bookholder.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "reading_sessions",
    foreignKeys = [ForeignKey(
        entity = UserBook::class,
        parentColumns = ["userBookId"],
        childColumns = ["userBookId"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class ReadingSession(
    @PrimaryKey(autoGenerate = true) val sessionId: Long = 0,
    val userBookId: Long,
    val date: Long,
    val pagesRead: Int,
    val durationMinutes: Int
)