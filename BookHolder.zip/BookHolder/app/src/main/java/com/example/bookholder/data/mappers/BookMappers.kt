package com.example.bookholder.data.mappers

import com.example.bookholder.data.local.entities.Book
import com.example.bookholder.data.remote.models.BookItem

object BookMappers {
    fun BookItem.toBook(): Book {
        return Book(
            id = this.id,
            title = this.volumeInfo.title,
            authors = this.volumeInfo.authors?.joinToString(", ") ?: "Autor Desconhecido",
            description = this.volumeInfo.description,
            thumbnailUrl = this.volumeInfo.imageLinks?.thumbnail,
            pageCount = this.volumeInfo.pageCount,
            publishedDate = this.volumeInfo.publishedDate,
            publisher = this.volumeInfo.publisher,
            isbn = this.volumeInfo.industryIdentifiers?.firstOrNull()?.identifier
        )
    }
}