package com.example.bookholder.data.remote.api

import retrofit2.Response
import retrofit2.http.*

interface JsonPlaceholderService {
    @POST("posts")
    suspend fun createPost(@Body post: Map<String, Any>): Response<Map<String, Any>>

    @PUT("posts/{id}")
    suspend fun updatePost(@Path("id") id: String, @Body post: Map<String, Any>): Response<Map<String, Any>>

    @DELETE("posts/{id}")
    suspend fun deletePost(@Path("id") id: String): Response<Unit>
}