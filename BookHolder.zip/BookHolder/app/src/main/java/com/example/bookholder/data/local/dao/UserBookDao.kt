package com.example.bookholder.data.local.dao

import androidx.room.*
import com.example.bookholder.data.local.entities.BookStatus
import com.example.bookholder.data.local.entities.UserBook
import kotlinx.coroutines.flow.Flow

@Dao
interface UserBookDao {
    @Query("SELECT * FROM user_books WHERE bookId = :bookId")
    suspend fun getUserBook(bookId: String): UserBook?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserBook(userBook: UserBook): Long

    @Update
    suspend fun updateUserBook(userBook: UserBook)

    @Query("DELETE FROM user_books WHERE userBookId = :userBookId")
    suspend fun deleteUserBook(userBookId: Long)

    @Query("SELECT * FROM user_books WHERE status = :status")
    fun getBooksByStatus(status: BookStatus): Flow<List<UserBook>>

    @Query("SELECT * FROM user_books")
    fun getAllUserBooks(): Flow<List<UserBook>>
}