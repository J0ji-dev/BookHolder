package com.example.bookholder.ui.screen.library

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.bookholder.libraryViewModel

@Composable
fun LibraryScreen(
    onNavigateToBookDetail: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    // Usa o helper que cria a VM com o ViewModelFactory correto
    val viewModel: LibraryViewModel = libraryViewModel()

    // ✅ Coleta o StateFlow como State (evita acessar .value na composição)
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "📚 Minha Biblioteca",
            style = MaterialTheme.typography.headlineMedium
        )

        when (val state = uiState) {
            is LibraryUiState.Loading -> {
                Text("Carregando biblioteca...")
            }
            is LibraryUiState.Empty -> {
                Text("Sua biblioteca está vazia!")
                Button(
                    onClick = { viewModel.addSampleData() },
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    Text("➕ Adicionar Livros de Exemplo")
                }
            }
            is LibraryUiState.Success -> {
                Text("Total de livros: ${state.userBooks.size}")

                LazyColumn {
                    items(state.userBooks) { userBook ->
                        Card(
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("ID: ${userBook.bookId}")
                                Text("Status: ${userBook.status}")
                                Text("Página: ${userBook.currentPage}")
                                Button(
                                    onClick = { onNavigateToBookDetail(userBook.bookId) },
                                    modifier = Modifier.padding(top = 8.dp)
                                ) {
                                    Text("Ver Detalhes")
                                }
                            }
                        }
                    }
                }
            }
            is LibraryUiState.Error -> {
                Text("Erro: ${state.message}")
                Button(
                    onClick = { viewModel.loadUserBooks() },
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    Text("🔄 Tentar Novamente")
                }
            }
        }

        Button(
            onClick = onNavigateBack,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("⬅️ Voltar para Home")
        }
    }
}

/**
 * Preview isolado (não depende da ViewModel).
 * Renderiza um conteúdo estático apenas para visualização no Android Studio.
 */
@Preview(showBackground = true)
@Composable
private fun LibraryScreenPreview() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "📚 Minha Biblioteca",
            style = MaterialTheme.typography.headlineMedium
        )
        Text("Total de livros: 2")

        LazyColumn {
            items(
                listOf(
                    "book1" to ("READING" to 50),
                    "book2" to ("WANT_TO_READ" to 0)
                )
            ) { (bookId, pair) ->
                val (status, page) = pair
                Card(
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("ID: $bookId")
                        Text("Status: $status")
                        Text("Página: $page")
                        Button(
                            onClick = { /* preview */ },
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            Text("Ver Detalhes")
                        }
                    }
                }
            }
        }

        Button(
            onClick = { /* preview */ },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("⬅️ Voltar para Home")
        }
    }
}
