package com.example.bookholder.ui.screen.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.bookholder.data.local.entities.Book
import com.example.bookholder.data.local.entities.BookStatus
import com.example.bookholder.data.local.entities.UserBook
import com.example.bookholder.data.repository.BookRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class LibraryViewModel(
    private val bookRepository: BookRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<LibraryUiState>(LibraryUiState.Loading)
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()

    init {
        loadUserBooks()
    }

    fun loadUserBooks() {
        viewModelScope.launch {
            try {
                _uiState.value = LibraryUiState.Loading
                val userBooks: List<UserBook> = bookRepository.getAllUserBooks().first()
                _uiState.value = if (userBooks.isEmpty()) {
                    LibraryUiState.Empty
                } else {
                    LibraryUiState.Success(userBooks)
                }
            } catch (e: Exception) {
                _uiState.value = LibraryUiState.Error("Erro ao carregar livros: ${e.message}")
            }
        }
    }

    fun addSampleData() {
        viewModelScope.launch {
            try {
                _uiState.value = LibraryUiState.Loading

                // Livros de exemplo (campos alinhados com sua entidade Book)
                val sampleBooks = listOf(
                    Book(
                        id = "book1",
                        title = "Dom Casmurro",
                        authors = "Machado de Assis",
                        description = "Romance clássico brasileiro",
                        thumbnailUrl = null,
                        pageCount = 256,
                        publishedDate = "1899",
                        publisher = "Editora A",
                        isbn = null
                    ),
                    Book(
                        id = "book2",
                        title = "O Cortiço",
                        authors = "Aluísio Azevedo",
                        description = "Naturalismo brasileiro",
                        thumbnailUrl = null,
                        pageCount = 300,
                        publishedDate = "1890",
                        publisher = "Editora B",
                        isbn = null
                    )
                )

                // Insere se ainda não existir (usando getBook)
                sampleBooks.forEach { book ->
                    val exists = bookRepository.getBook(book.id)
                    if (exists == null) {
                        bookRepository.insertBook(book)
                    }
                }

                // Insere UserBooks de exemplo (userBookId = 0L para autoincrement)
                val toInsert = listOf(
                    UserBook(
                        userBookId = 0L,
                        bookId = "book1",
                        addedDate = System.currentTimeMillis(),
                        status = BookStatus.READING,
                        currentPage = 50,
                        rating = null // ajuste se seu UserBook tiver rating nullable/padrão
                    ),
                    UserBook(
                        userBookId = 0L,
                        bookId = "book2",
                        addedDate = System.currentTimeMillis(),
                        status = BookStatus.WANT_TO_READ,
                        currentPage = 0,
                        rating = null
                    )
                )

                toInsert.forEach { userBook ->
                    try {
                        bookRepository.insertUserBook(userBook)
                    } catch (_: Exception) {
                        // Se já existir, ignore
                    }
                }

                // Recarrega a lista (snapshot do Flow)
                val userBooks = bookRepository.getAllUserBooks().first()
                _uiState.value = if (userBooks.isEmpty()) {
                    LibraryUiState.Empty
                } else {
                    LibraryUiState.Success(userBooks)
                }
            } catch (e: Exception) {
                _uiState.value = LibraryUiState.Error("Erro ao adicionar dados: ${e.message}")
            }
        }
    }

    fun updateReadingProgress(userBookId: Long, currentPage: Int) {
        viewModelScope.launch {
            try {
                val all = bookRepository.getAllUserBooks().first()
                val current = all.find { it.userBookId == userBookId }
                    ?: return@launch run {
                        _uiState.value = LibraryUiState.Error("UserBook $userBookId não encontrado")
                    }

                bookRepository.updateUserBook(current.copy(currentPage = currentPage))

                val userBooks = bookRepository.getAllUserBooks().first()
                _uiState.value = if (userBooks.isEmpty()) LibraryUiState.Empty else LibraryUiState.Success(userBooks)
            } catch (e: Exception) {
                _uiState.value = LibraryUiState.Error("Erro ao atualizar progresso: ${e.message}")
            }
        }
    }

    fun updateBookStatus(userBookId: Long, status: BookStatus) {
        viewModelScope.launch {
            try {
                val all = bookRepository.getAllUserBooks().first()
                val current = all.find { it.userBookId == userBookId }
                    ?: return@launch run {
                        _uiState.value = LibraryUiState.Error("UserBook $userBookId não encontrado")
                    }

                bookRepository.updateUserBook(current.copy(status = status))

                val userBooks = bookRepository.getAllUserBooks().first()
                _uiState.value = if (userBooks.isEmpty()) LibraryUiState.Empty else LibraryUiState.Success(userBooks)
            } catch (e: Exception) {
                _uiState.value = LibraryUiState.Error("Erro ao atualizar status: ${e.message}")
            }
        }
    }

    fun removeUserBook(userBookId: Long) {
        viewModelScope.launch {
            try {
                bookRepository.deleteUserBook(userBookId)

                val userBooks = bookRepository.getAllUserBooks().first()
                _uiState.value = if (userBooks.isEmpty()) LibraryUiState.Empty else LibraryUiState.Success(userBooks)
            } catch (e: Exception) {
                _uiState.value = LibraryUiState.Error("Erro ao remover livro: ${e.message}")
            }
        }
    }
}

sealed class LibraryUiState {
    object Loading : LibraryUiState()
    object Empty : LibraryUiState()
    data class Success(val userBooks: List<UserBook>) : LibraryUiState()
    data class Error(val message: String) : LibraryUiState()
}
