package com.example.bookholder.ui.theme.screen.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SearchViewModel() : ViewModel() {

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    fun searchBooks(query: String) {
        if (query.isBlank()) return

        viewModelScope.launch {
            _uiState.value = SearchUiState.Loading
            try {
                // Simula uma busca por 1 segundo
                kotlinx.coroutines.delay(1000)

                // Dados MOCK temporários - REMOVA depois
                _uiState.value = SearchUiState.Success(emptyList())
            } catch (e: Exception) {
                _uiState.value = SearchUiState.Error(e.message ?: "Erro desconhecido")
            }
        }
    }

    fun clearSearch() {
        _uiState.value = SearchUiState.Idle
    }
}

sealed class SearchUiState {
    object Idle : SearchUiState()
    object Loading : SearchUiState()
    data class Success(val books: List<com.example.bookholder.data.local.entities.Book>) : SearchUiState()
    data class Error(val message: String) : SearchUiState()
}