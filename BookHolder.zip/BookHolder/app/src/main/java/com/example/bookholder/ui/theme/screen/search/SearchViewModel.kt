package com.example.bookholder.ui.screen.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.bookholder.data.mappers.BookMappers
import com.example.bookholder.data.repository.BookRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SearchViewModel(private val repository: BookRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    fun searchBooks(query: String) {
        if (query.isBlank()) return

        viewModelScope.launch {
            _uiState.value = SearchUiState.Loading
            try {
                val bookItems = repository.searchBooks(query)
                val books = bookItems.map { BookMappers.BookItem.toBook(it) }
                _uiState.value = SearchUiState.Success(books)
            } catch (e: Exception) {
                _uiState.value = SearchUiState.Error(e.message ?: "Erro desconhecido")
            }
        }
    }

    fun clearSearch() {
        _uiState.value = SearchUiState.Idle
    }
}

sealed class SearchUiState {
    object Idle : SearchUiState()
    object Loading : SearchUiState()
    data class Success(val books: List<com.example.bookholder.data.local.entities.Book>) : SearchUiState()
    data class Error(val message: String) : SearchUiState()
}