package com.example.bookholder.data.remote

import com.example.bookholder.data.remote.api.BooksApiService
import com.example.bookholder.data.remote.api.JsonPlaceholderService
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {
    private const val GOOGLE_BOOKS_BASE_URL = "https://www.googleapis.com/books/v1/"
    private const val JSON_PLACEHOLDER_BASE_URL = "https://jsonplaceholder.typicode.com/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val googleBooksRetrofit = Retrofit.Builder()
        .baseUrl(GOOGLE_BOOKS_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val jsonPlaceholderRetrofit = Retrofit.Builder()
        .baseUrl(JSON_PLACEHOLDER_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val booksApiService: BooksApiService by lazy {
        googleBooksRetrofit.create(BooksApiService::class.java)
    }

    val jsonPlaceholderService: JsonPlaceholderService by lazy {
        jsonPlaceholderRetrofit.create(JsonPlaceholderService::class.java)
    }
}