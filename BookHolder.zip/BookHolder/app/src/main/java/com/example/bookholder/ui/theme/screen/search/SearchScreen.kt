package com.example.bookholder.ui.theme.screen.search

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun SearchScreen(
    onNavigateToBookDetail: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val viewModel: SearchViewModel = viewModel()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "🔍 Buscar Livros",
            style = androidx.compose.material3.MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Título, autor ou ISBN") },
            modifier = Modifier.padding(vertical = 8.dp)
        )

        Button(
            onClick = {
                viewModel.searchBooks(searchQuery)
            },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("Buscar")
        }

        Button(
            onClick = {
                onNavigateToBookDetail("mock-book-id")
            },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("Ver Detalhes (Teste)")
        }

        Button(
            onClick = onNavigateBack,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("⬅️ Voltar")
        }
    }
}

@Preview
@Composable
fun SearchScreenPreview() {
    SearchScreen(
        onNavigateToBookDetail = {},
        onNavigateBack = {}
    )
}