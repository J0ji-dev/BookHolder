package com.example.bookholder

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import com.example.bookholder.navigation.Screen
import com.example.bookholder.navigation.appGraph
import com.example.bookholder.ui.theme.BookHolderTheme
import com.example.bookholder.data.local.BookDatabase
import com.example.bookholder.data.repository.BookRepository
import com.example.bookholder.ui.viewmodel.ViewModelFactory

// ViewModel correta (sem "theme" no pacote)
import com.example.bookholder.ui.screen.library.LibraryViewModel

// 🔗 Rede
import com.example.bookholder.data.remote.NetworkModule
import com.example.bookholder.data.remote.RemoteDataSource
import com.example.bookholder.data.remote.api.BooksApiService
import com.example.bookholder.data.remote.api.JsonPlaceholderService

// Objeto global simples (temporário)
object AppContainer {
    lateinit var bookRepository: BookRepository
    lateinit var viewModelFactory: ViewModelFactory

    fun initialize(context: Context) {
        // DB
        val database = BookDatabase.getInstance(context)

        // Services de rede
        val booksService: BooksApiService = NetworkModule.provideBooksApiService(
            baseUrl = "https://www.googleapis.com/books/v1/"
        )
        val jsonService: JsonPlaceholderService = NetworkModule.provideJsonPlaceholderService(
            baseUrl = "https://jsonplaceholder.typicode.com/"
        )

        // DataSource remoto
        val remote = RemoteDataSource(booksService, jsonService)

        // Repositório com DB + remoto
        bookRepository = BookRepository(database, remote)

        // Factory das ViewModels
        viewModelFactory = ViewModelFactory(bookRepository)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializa o container da app
        AppContainer.initialize(this)

        setContent {
            BookHolderTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BookHolderApp()
                }
            }
        }
    }
}

@Composable
fun libraryViewModel(): LibraryViewModel {
    val factory = AppContainer.viewModelFactory
    val viewModelStoreOwner = LocalViewModelStoreOwner.current
        ?: throw IllegalStateException("No ViewModelStoreOwner")

    // usa o genérico para garantir o tipo correto
    return viewModel<LibraryViewModel>(
        factory = factory,
        viewModelStoreOwner = viewModelStoreOwner
    )
}

@Composable
fun BookHolderApp() {
    val navController = rememberNavController()

    val onNavigateToHome: () -> Unit = {
        navController.navigate(Screen.Home.route) {
            popUpTo(Screen.Splash.route) { inclusive = true }
        }
    }

    val onNavigateToSearch: () -> Unit = {
        navController.navigate(Screen.Search.route)
    }

    val onNavigateToLibrary: () -> Unit = {
        navController.navigate(Screen.Library.route)
    }

    val onNavigateToStats: () -> Unit = {
        navController.navigate(Screen.Stats.route)
    }

    val onNavigateToBookDetail: (String) -> Unit = { bookId ->
        navController.navigate(Screen.BookDetail.createRoute(bookId))
    }

    val onNavigateToEditProgress: (String) -> Unit = { bookId ->
        navController.navigate(Screen.EditProgress.createRoute(bookId))
    }

    val onNavigateBack: () -> Unit = {
        navController.popBackStack()
    }

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        appGraph(
            onNavigateToHome = onNavigateToHome,
            onNavigateToSearch = onNavigateToSearch,
            onNavigateToLibrary = onNavigateToLibrary,
            onNavigateToStats = onNavigateToStats,
            onNavigateToBookDetail = onNavigateToBookDetail,
            onNavigateToEditProgress = onNavigateToEditProgress,
            onNavigateBack = onNavigateBack
        )
    }
}
