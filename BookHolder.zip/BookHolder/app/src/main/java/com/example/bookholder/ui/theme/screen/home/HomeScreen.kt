package com.example.bookholder.ui.theme.screen.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(
    onNavigateToSearch: () -> Unit,
    onNavigateToLibrary: () -> Unit,
    onNavigateToStats: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("📚 BookHolder", style = androidx.compose.material3.MaterialTheme.typography.headlineLarge)

        Button(
            onClick = onNavigateToSearch,
            modifier = Modifier.padding(8.dp)
        ) {
            Text("🔍 Buscar Livros")
        }

        Button(
            onClick = onNavigateToLibrary,
            modifier = Modifier.padding(8.dp)
        ) {
            Text("📖 Minha Biblioteca")
        }

        Button(
            onClick = onNavigateToStats,
            modifier = Modifier.padding(8.dp)
        ) {
            Text("📊 Estatísticas")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    HomeScreen(
        onNavigateToSearch = {},
        onNavigateToLibrary = {},
        onNavigateToStats = {}
    )
}