package com.example.bookholder.data.remote

import com.example.bookholder.data.remote.api.BooksApiService
import com.example.bookholder.data.remote.api.JsonPlaceholderService
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkModule {

    private const val TIMEOUT_SECONDS = 20L

    private fun loggingInterceptor(): Interceptor {
        val logger = HttpLoggingInterceptor()
        logger.level = HttpLoggingInterceptor.Level.BODY // em release troque para BASIC
        return logger
    }

    private fun baseClient(extraInterceptors: List<Interceptor> = emptyList()): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .readTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .writeTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor())

        extraInterceptors.forEach { builder.addInterceptor(it) }
        return builder.build()
    }

    private fun retrofit(baseUrl: String, client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    fun provideBooksApiService(
        baseUrl: String = "https://www.googleapis.com/books/v1/",
        interceptors: List<Interceptor> = emptyList()
    ): BooksApiService {
        val client = baseClient(interceptors)
        return retrofit(baseUrl, client).create(BooksApiService::class.java)
    }

    fun provideJsonPlaceholderService(
        baseUrl: String = "https://jsonplaceholder.typicode.com/",
        interceptors: List<Interceptor> = emptyList()
    ): JsonPlaceholderService {
        val client = baseClient(interceptors)
        return retrofit(baseUrl, client).create(JsonPlaceholderService::class.java)
    }
}
