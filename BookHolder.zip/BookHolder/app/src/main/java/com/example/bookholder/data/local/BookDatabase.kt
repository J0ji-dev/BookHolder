package com.example.bookholder.data.local

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import com.example.bookholder.data.local.dao.BookDao
import com.example.bookholder.data.local.dao.UserBookDao
import com.example.bookholder.data.local.entities.Book
import com.example.bookholder.data.local.entities.UserBook
import com.example.bookholder.data.local.entities.ReadingSession

@Database(
    entities = [Book::class, UserBook::class, ReadingSession::class],
    version = 1,
    exportSchema = false
)
abstract class BookDatabase : RoomDatabase() {
    abstract fun bookDao(): BookDao
    abstract fun userBookDao(): UserBookDao

    companion object {
        @Volatile
        private var INSTANCE: BookDatabase? = null

        fun getInstance(context: Context): BookDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BookDatabase::class.java,
                    "book_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}