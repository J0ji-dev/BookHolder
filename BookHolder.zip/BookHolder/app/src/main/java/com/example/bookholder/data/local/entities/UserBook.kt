package com.example.bookholder.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "user_books",
    foreignKeys = [ForeignKey(
        entity = Book::class,
        parentColumns = ["id"],
        childColumns = ["bookId"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class UserBook(
    @PrimaryKey(autoGenerate = true) val userBookId: Long = 0,
    val bookId: String,
    val addedDate: Long,
    val status: BookStatus,
    val currentPage: Int = 0,
    val rating: Float? = null,
    val notes: String? = null,
    val startDate: Long? = null,
    val finishDate: Long? = null
)

enum class BookStatus {
    WANT_TO_READ, READING, FINISHED
}