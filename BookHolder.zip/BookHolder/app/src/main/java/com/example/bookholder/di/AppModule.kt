package com.example.bookholder.di

import android.content.Context
import com.example.bookholder.data.local.BookDatabase
import com.example.bookholder.data.remote.NetworkModule
import com.example.bookholder.data.remote.RemoteDataSource
import com.example.bookholder.data.remote.api.BooksApiService
import com.example.bookholder.data.remote.api.JsonPlaceholderService
import com.example.bookholder.data.repository.BookRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    // --- Database ---
    @Provides
    @Singleton
    fun provideBookDatabase(@ApplicationContext context: Context): BookDatabase {
        return BookDatabase.getInstance(context)
    }

    // --- Services de rede (Google Books & JSONPlaceholder) ---
    @Provides
    @Singleton
    fun provideBooksApiService(): BooksApiService {
        // Base URL oficial do Google Books
        return NetworkModule.provideBooksApiService(
            baseUrl = "https://www.googleapis.com/books/v1/"
        )
    }

    @Provides
    @Singleton
    fun provideJsonPlaceholderService(): JsonPlaceholderService {
        return NetworkModule.provideJsonPlaceholderService(
            baseUrl = "https://jsonplaceholder.typicode.com/"
        )
    }

    // --- DataSource remoto que encapsula os services ---
    @Provides
    @Singleton
    fun provideRemoteDataSource(
        booksApiService: BooksApiService,
        jsonPlaceholderService: JsonPlaceholderService
    ): RemoteDataSource {
        return RemoteDataSource(
            booksApi = booksApiService,
            jsonService = jsonPlaceholderService
        )
    }

    // --- Repositório agora recebe database + remote ---
    @Provides
    @Singleton
    fun provideBookRepository(
        database: BookDatabase,
        remote: RemoteDataSource
    ): BookRepository {
        return BookRepository(database, remote)
    }
}
