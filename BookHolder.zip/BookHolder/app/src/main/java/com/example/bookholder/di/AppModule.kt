package com.example.bookholder.di

import android.content.Context
import com.example.bookholder.data.local.BookDatabase
import com.example.bookholder.data.repository.BookRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideBookDatabase(@ApplicationContext context: Context): BookDatabase {
        return BookDatabase.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideBookRepository(database: BookDatabase): BookRepository {
        return BookRepository(database)
    }
}