package com.example.bookholder.ui.screen.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {

    private val _navigationEvent = Channel<String>()
    val navigationEvent = _navigationEvent.receiveAsFlow()

    fun navigateToSearch() {
        viewModelScope.launch {
            _navigationEvent.send("search")
        }
    }

    fun navigateToLibrary() {
        viewModelScope.launch {
            _navigationEvent.send("library")
        }
    }

    fun navigateToStats() {
        viewModelScope.launch {
            _navigationEvent.send("stats")
        }
    }
}