package com.example.lapelusca.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.lapelusca.data.LibraryRepository
import kotlinx.coroutines.launch

class EditProgressViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = LibraryRepository(app)

    /** Marca o livro como Lido (finalizado). */
    fun markFinished(userBookId: String, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repo.markFinished(userBookId)
            onDone()
        }
    }
}
