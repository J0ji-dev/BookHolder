package com.example.lapelusca.data

import android.content.Context
import com.example.lapelusca.data.local.AppDatabase
import com.example.lapelusca.data.local.Book
import com.example.lapelusca.data.local.UserBook
import com.example.lapelusca.data.model.Book as ApiBook
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LibraryRepository(context: Context) {
    private val db = AppDatabase.get(context)
    private val bookDao = db.bookDao()
    private val userBookDao = db.userBookDao()

    /**
     * Adiciona um livro da API à biblioteca local com status "Lendo".
     * Se já existir, mantém/ajusta status para "Lendo".
     */
    suspend fun addToLibrary(book: ApiBook) = withContext(Dispatchers.IO) {
        val local = Book(
            id = book.id,
            title = book.title,
            authors = book.authors,
            thumbnail = book.thumbnail,
            pageCount = book.pageCount
        )
        bookDao.upsert(local)

        val existing = userBookDao.get(book.id)
        if (existing == null) {
            userBookDao.upsert(
                UserBook(
                    id = book.id,
                    status = "Lendo",
                    currentPage = 0,
                    totalPages = book.pageCount
                )
            )
        } else if (existing.status != "Lendo") {
            userBookDao.upsert(existing.copy(status = "Lendo"))
        }
    }

    /**
     * Marca como "Lido".
     */
    suspend fun markFinished(id: String) = withContext(Dispatchers.IO) {
        val ub = userBookDao.get(id) ?: return@withContext
        userBookDao.update(ub.copy(status = "Lido"))
    }

    /**
     * Lista (Book, UserBook) para a Biblioteca.
     */
    suspend fun library(): List<Pair<Book, UserBook>> = withContext(Dispatchers.IO) {
        val books = bookDao.getAll().associateBy { it.id }
        val ubs = userBookDao.getAll()
        ubs.mapNotNull { ub -> books[ub.id]?.let { it to ub } }
    }

    /**
     * Estatística simples: total de livros com status "Lido".
     */
    suspend fun totalRead(): Int = withContext(Dispatchers.IO) {
        userBookDao.getAll().count { it.status == "Lido" }
    }
}
