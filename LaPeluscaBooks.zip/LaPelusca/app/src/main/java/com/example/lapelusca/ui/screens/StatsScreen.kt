package com.example.lapelusca.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.lapelusca.ui.components.AppTopBar
import com.example.lapelusca.ui.vm.StatsViewModel

@Composable
fun StatsScreen(
    onBack: () -> Unit,
    vm: StatsViewModel = viewModel()
) {
    val stats by vm.stats.collectAsState()
    LaunchedEffect(Unit) { vm.load() }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = "Estatísticas", onBack = onBack)

        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Livros lidos", fontSize = 20.sp)
                Spacer(Modifier.height(8.dp))
                Text(text = stats.totalRead.toString(), fontSize = 40.sp)
            }
        }
    }
}
