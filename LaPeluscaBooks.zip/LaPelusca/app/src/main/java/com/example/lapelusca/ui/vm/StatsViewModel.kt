package com.example.lapelusca.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.lapelusca.data.LibraryRepository
import com.example.lapelusca.data.model.Stats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class StatsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = LibraryRepository(app)

    private val _stats = MutableStateFlow(Stats(totalRead = 0, totalMinutes = 0))
    val stats = _stats.asStateFlow()

    fun load() {
        viewModelScope.launch {
            val read = repo.totalRead()
            _stats.value = Stats(totalRead = read, totalMinutes = 0)
        }
    }
}
