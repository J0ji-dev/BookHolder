package com.example.lapelusca.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.lapelusca.data.BooksRepository
import com.example.lapelusca.data.model.Book
import com.example.lapelusca.ui.components.AppTopBar
import com.example.lapelusca.ui.vm.AddToLibraryViewModel
import kotlinx.coroutines.launch

@Composable
fun BookDetailScreen(
    bookId: String,
    onAdded: () -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val repo = remember { BooksRepository() }
    val addVm: AddToLibraryViewModel = viewModel()

    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var book by remember { mutableStateOf<Book?>(null) }

    LaunchedEffect(bookId) {
        loading = true
        error = null
        runCatching { repo.fetchDetails(bookId) }
            .onSuccess { book = it }
            .onFailure { error = it.message ?: "Erro ao carregar detalhes" }
        loading = false
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = "Detalhes do Livro", onBack = onBack)

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(error!!)
            }
            book != null -> {
                val b = book!!
                Column(Modifier.fillMaxSize().padding(16.dp)) {
                    if (!b.thumbnail.isNullOrBlank()) {
                        AsyncImage(
                            model = b.thumbnail,
                            contentDescription = null,
                            modifier = Modifier.fillMaxWidth().height(240.dp)
                        )
                        Spacer(Modifier.height(16.dp))
                    }
                    Text(b.title, style = MaterialTheme.typography.titleLarge)
                    if (!b.authors.isNullOrBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(b.authors!!, style = MaterialTheme.typography.bodyMedium)
                    }
                    if (b.pageCount != null) {
                        Spacer(Modifier.height(6.dp))
                        Text("${b.pageCount} páginas", style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { scope.launch { addVm.add(b) { onAdded() } } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Adicionar à biblioteca") }
                }
            }
        }
    }
}
