package com.example.lapelusca.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class Book(
    @PrimaryKey val id: String,
    val title: String,
    val authors: String?,
    val thumbnail: String?,
    val pageCount: Int?
)
