package com.example.lapelusca.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.lapelusca.ui.components.AppTopBar
import com.example.lapelusca.ui.vm.BooksSearchViewModel

@Composable
fun SearchScreen(
    onOpenBook: (String) -> Unit,
    onBack: () -> Unit,
    vm: BooksSearchViewModel = viewModel()

) {
    var q by remember { mutableStateOf("android") }
    val loading by vm.loading.collectAsState()
    val results by vm.results.collectAsState()
    val error by vm.error.collectAsState()

    LaunchedEffect(Unit) { vm.search(q) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        AppTopBar(title = "Buscar Livros", onBack = onBack)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                label = { Text("Buscar livros") },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.search(q) }) { Text("Buscar") }
        }

        if (loading) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        error?.let { if (it.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text("Erro: $it", color = MaterialTheme.colorScheme.error)
        }}

        Spacer(Modifier.height(8.dp))

        LazyColumn {
            items(results) { book ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = rememberAsyncImagePainter(book.thumbnail),
                        contentDescription = null,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            book.title,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            book.authors ?: "Autor desconhecido",
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "Páginas: ${book.pageCount ?: 0}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { onOpenBook(book.id) }) { Text("Detalhes") }
                }
                Divider()
            }
        }
    }
}
