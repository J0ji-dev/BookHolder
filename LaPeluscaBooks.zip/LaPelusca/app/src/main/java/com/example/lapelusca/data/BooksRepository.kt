package com.example.lapelusca.data

import android.util.Log
import com.example.lapelusca.data.model.Book
import com.example.lapelusca.data.remote.NetworkModule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class BooksRepository {
    private val tag = "BooksRepository"
    private val google = NetworkModule.googleBooks()

    private fun secure(url: String?): String? {
        if (url.isNullOrBlank()) return null
        var fixed = if (url.startsWith("http://"))
            url.replaceFirst("http://", "https://")
        else url
        fixed = fixed
            .replace("https://books.google.com.br/books/content", "https://books.google.com/books/content")
            .replace("https://google.com/books/content", "https://books.google.com/books/content")
            .replace("https://http://", "https://")
        return fixed
    }

    suspend fun searchBooks(query: String): List<Book> = withContext(Dispatchers.IO) {
        try {
            val resp = google.search(q = query, max = 20)
            val items = resp.items ?: emptyList()
            items.map { item ->
                val info = item.info
                Book(
                    id = item.id,
                    title = info.title.orEmpty(),
                    authors = info.authors?.joinToString(", "),
                    thumbnail = secure(info.imageLinks?.thumbnail ?: info.imageLinks?.smallThumbnail),
                    pageCount = info.pageCount
                )
            }
        } catch (t: Throwable) {
            Log.e(tag, "searchBooks failed", t)
            emptyList()
        }
    }

    suspend fun fetchDetails(id: String): Book = withContext(Dispatchers.IO) {
        try {
            val item = google.details(id)
            val info = item.info
            Book(
                id = item.id,
                title = info.title.orEmpty(),
                authors = info.authors?.joinToString(", "),
                thumbnail = secure(info.imageLinks?.thumbnail ?: info.imageLinks?.smallThumbnail),
                pageCount = info.pageCount
            )
        } catch (t: Throwable) {
            Log.e(tag, "details failed", t)
            Book(id = id, title = "Desconhecido", authors = null, thumbnail = null, pageCount = null)
        }
    }
}
