package com.example.lapelusca.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.lapelusca.data.LibraryRepository
import com.example.lapelusca.data.local.Book
import com.example.lapelusca.data.local.UserBook
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = LibraryRepository(app)

    private val _items = MutableStateFlow<List<Pair<Book, UserBook>>>(emptyList())
    val items = _items.asStateFlow()

    fun load() {
        viewModelScope.launch { _items.value = repo.library() }
    }

    fun markFinished(id: String) {
        viewModelScope.launch {
            repo.markFinished(id)
            _items.value = repo.library() // refresh após finalizar
        }
    }
}
