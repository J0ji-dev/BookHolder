package com.example.lapelusca.data.model

data class Book(
    val id: String,
    val title: String,
    val authors: String?,
    val thumbnail: String?,
    val pageCount: Int?
)
