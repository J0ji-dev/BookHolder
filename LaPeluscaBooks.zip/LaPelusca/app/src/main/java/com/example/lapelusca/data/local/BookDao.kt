package com.example.lapelusca.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert

@Dao
interface BookDao {
    @Upsert
    suspend fun upsert(book: Book)

    @Query("SELECT * FROM books WHERE id = :id")
    suspend fun getById(id: String): Book?

    @Query("SELECT * FROM books")
    suspend fun getAll(): List<Book>

    @Query("DELETE FROM books WHERE id = :id")
    suspend fun delete(id: String)
}
