package com.example.lapelusca.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.lapelusca.ui.vm.EditProgressViewModel

@Composable
fun EditProgressScreen(userBookId: String, onDone: () -> Unit, vm: EditProgressViewModel = viewModel()) {
    var page by remember { mutableStateOf("0") }
    var status by remember { mutableStateOf("Lendo") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Atualizar progresso: $userBookId")
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = page, onValueChange = { page = it }, label = { Text("Página atual") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = status, onValueChange = { status = it }, label = { Text("Status") })
        Spacer(Modifier.height(12.dp))
        Button(onClick = { vm.markFinished(userBookId, onDone) }) { /* "Finalizado" */ }
        Text("Salvar")
        }
    }
