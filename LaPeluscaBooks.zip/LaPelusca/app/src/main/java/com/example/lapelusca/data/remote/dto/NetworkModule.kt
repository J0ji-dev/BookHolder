package com.example.lapelusca.data.remote

import com.example.lapelusca.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object NetworkModule {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    // Fallback: usa BuildConfig.GOOGLE_BOOKS_KEY se existir, senão usa a sua key fixa
    private val GOOGLE_KEY: String by lazy {
        val fromBuild = BuildConfig.GOOGLE_BOOKS_KEY ?: ""
        if (fromBuild.isNotBlank()) fromBuild
        else "AIzaSyB3dExQWcVE7NJYH77hIlgKwQvqUxZ3a4I"
    }

    private fun googleKeyInterceptor(): Interceptor = Interceptor { chain ->
        val req = chain.request()
        val url = req.url
        val needsKey = url.host == "www.googleapis.com" &&
                GOOGLE_KEY.isNotBlank() &&
                !url.queryParameterNames.contains("key")

        val newReq = if (needsKey) {
            val newUrl = url.newBuilder().addQueryParameter("key", GOOGLE_KEY).build()
            req.newBuilder().url(newUrl).build()
        } else req

        chain.proceed(newReq)
    }

    private fun client(addKey: Boolean = false): OkHttpClient {
        val log = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
        return OkHttpClient.Builder()
            .addInterceptor(log)
            .apply { if (addKey) addInterceptor(googleKeyInterceptor()) }
            .build()
    }

    fun googleBooks(): GoogleBooksApi =
        Retrofit.Builder()
            .baseUrl("https://www.googleapis.com/books/v1/")
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .client(client(addKey = true))
            .build()
            .create(GoogleBooksApi::class.java)
}
