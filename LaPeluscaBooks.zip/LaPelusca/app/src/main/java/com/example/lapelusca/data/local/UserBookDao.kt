package com.example.lapelusca.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert

@Dao
interface UserBookDao {
    @Upsert
    suspend fun upsert(userBook: UserBook)

    @Update
    suspend fun update(userBook: UserBook)

    @Query("SELECT * FROM user_books WHERE id = :id")
    suspend fun get(id: String): UserBook?

    @Query("SELECT * FROM user_books")
    suspend fun getAll(): List<UserBook>

    @Query("DELETE FROM user_books WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT EXISTS(SELECT 1 FROM user_books WHERE id = :id)")
    suspend fun exists(id: String): Boolean
}
