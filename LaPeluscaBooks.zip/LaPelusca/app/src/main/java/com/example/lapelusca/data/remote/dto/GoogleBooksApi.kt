package com.example.lapelusca.data.remote

import com.example.lapelusca.data.remote.dto.VolumeItem
import com.example.lapelusca.data.remote.dto.VolumeSearchResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface GoogleBooksApi {
    @GET("volumes")
    suspend fun search(
        @Query("q") q: String,
        @Query("maxResults") max: Int = 20
    ): VolumeSearchResponse

    @GET("volumes/{id}")
    suspend fun details(@Path("id") id: String): VolumeItem
}
