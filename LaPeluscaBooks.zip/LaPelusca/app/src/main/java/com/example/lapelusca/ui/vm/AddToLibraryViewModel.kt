package com.example.lapelusca.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.lapelusca.data.LibraryRepository
import com.example.lapelusca.data.model.Book
import kotlinx.coroutines.launch

class AddToLibraryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = LibraryRepository(app)

    fun add(book: Book, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repo.addToLibrary(book)
            onDone()
        }
    }
}
