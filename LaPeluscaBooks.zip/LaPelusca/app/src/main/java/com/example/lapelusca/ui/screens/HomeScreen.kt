// app/src/main/java/com/example/lapelusca/ui/screens/HomeScreen.kt
package com.example.lapelusca.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.lapelusca.ui.components.AppTopBar

@Composable
fun HomeScreen(
    goToSearch: () -> Unit,
    goToLibrary: () -> Unit,
    goToStats: () -> Unit,
    onBack: () -> Unit        // <— adicionamos este parâmetro
) {
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = "BookHolder", onBack = onBack)

        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Button(onClick = goToSearch, modifier = Modifier.fillMaxWidth()) {
                Text("Buscar Livros")
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = goToLibrary, modifier = Modifier.fillMaxWidth()) {
                Text("Minha Biblioteca")
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = goToStats, modifier = Modifier.fillMaxWidth()) {
                Text("Estatísticas")
            }
        }
    }
}
