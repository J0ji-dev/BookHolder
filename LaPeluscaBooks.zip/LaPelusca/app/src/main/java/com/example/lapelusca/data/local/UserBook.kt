package com.example.lapelusca.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "user_books",
    foreignKeys = [
        ForeignKey(
            entity = Book::class,
            parentColumns = ["id"],
            childColumns = ["id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class UserBook(
    @PrimaryKey val id: String,  // mesmo id do Book
    val status: String,          // Quero Ler, Lendo, Lido
    val currentPage: Int,
    val totalPages: Int?
)
