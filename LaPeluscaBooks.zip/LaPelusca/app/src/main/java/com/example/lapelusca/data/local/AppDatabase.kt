package com.example.lapelusca.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Book::class, UserBook::class],
    version = 2,                // ↑ bump de versão porque removemos tabela
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bookDao(): BookDao
    abstract fun userBookDao(): UserBookDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "bookholder.db"
                )
                    .fallbackToDestructiveMigration() // ok para recriar sem reading_sessions
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
