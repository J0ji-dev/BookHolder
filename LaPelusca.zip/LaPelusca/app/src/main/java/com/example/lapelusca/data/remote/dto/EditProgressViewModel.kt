package com.example.lapelusca.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class EditProgressViewModel(app: Application) : AndroidViewModel(app) {

    /**
     * Por enquanto não há endpoint de atualização (Google Books não oferece isso).
     * Quando ligarmos o Room/local storage, faremos o update real.
     */
    fun update(userBookId: String, current: Int, status: String, onDone: () -> Unit) {
        viewModelScope.launch {
            // TODO: implementar persistência local (Room) quando for a hora
            onDone()
        }
    }
}
