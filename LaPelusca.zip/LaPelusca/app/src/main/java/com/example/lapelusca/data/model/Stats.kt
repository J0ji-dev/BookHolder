package com.example.lapelusca.data.model

data class Stats(
    val totalRead: Int,
    val totalMinutes: Int
)
