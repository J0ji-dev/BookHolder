package com.example.lapelusca.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.lapelusca.data.model.Stats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class StatsViewModel(app: Application) : AndroidViewModel(app) {

    private val _stats = MutableStateFlow(Stats(totalRead = 0, totalMinutes = 0))
    val stats = _stats.asStateFlow()

    /**
     * Por enquanto não temos fonte local (Room) para calcular estatísticas.
     * Mantemos valores padrão e, quando ligarmos Room, calculamos aqui.
     */
    fun load() {
        viewModelScope.launch {
            // TODO: quando integrar Room, carregar sessões/leitura e calcular
            _stats.value = _stats.value
        }
    }
}
