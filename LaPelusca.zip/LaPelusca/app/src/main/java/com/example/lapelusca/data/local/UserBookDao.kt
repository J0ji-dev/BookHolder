package com.example.lapelusca.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface UserBookDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(userBook: UserBook)

    @Update
    suspend fun update(userBook: UserBook)

    @Query("DELETE FROM user_books WHERE id = :bookId")
    suspend fun delete(bookId: String)

    @Query("SELECT * FROM user_books WHERE id = :bookId")
    suspend fun get(bookId: String): UserBook?

    @Query("SELECT * FROM user_books")
    suspend fun getAll(): List<UserBook>
}
