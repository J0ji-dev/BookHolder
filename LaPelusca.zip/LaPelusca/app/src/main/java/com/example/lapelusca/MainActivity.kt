package com.example.lapelusca

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.lapelusca.ui.screens.BookDetailScreen
import com.example.lapelusca.ui.screens.EditProgressScreen
import com.example.lapelusca.ui.screens.HomeScreen
import com.example.lapelusca.ui.screens.LibraryScreen
import com.example.lapelusca.ui.screens.SearchScreen
import com.example.lapelusca.ui.screens.SplashScreen
import com.example.lapelusca.ui.screens.StatsScreen
import com.example.lapelusca.ui.theme.LaPeluscaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LaPeluscaTheme {
                val navController = rememberNavController()
                Scaffold(modifier = Modifier.fillMaxSize()) { _ ->
                    AppNavHost(navController = navController)
                }
            }
        }
    }
}

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val SEARCH = "search"
    const val DETAIL = "bookDetail/{bookId}"
    const val LIBRARY = "library"
    const val EDIT = "editProgress/{userBookId}"
    const val STATS = "stats"
}

@Composable
fun AppNavHost(navController: NavHostController, modifier: Modifier = Modifier) {
    NavHost(
        navController = navController,
        startDestination = Routes.SPLASH
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onFinish = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                goToSearch = { navController.navigate(Routes.SEARCH) },
                goToLibrary = { navController.navigate(Routes.LIBRARY) },
                goToStats = { navController.navigate(Routes.STATS) }
            )
        }
        composable(Routes.SEARCH) {
            SearchScreen(
                onOpenBook = { bookId ->
                    navController.navigate("bookDetail/$bookId")
                }
            )
        }
        composable(Routes.DETAIL) { backStack ->
            val bookId = backStack.arguments?.getString("bookId") ?: ""
            BookDetailScreen(
                bookId = bookId,
                onAddOrEdit = { userBookId ->
                    navController.navigate("editProgress/$userBookId")
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.LIBRARY) {
            LibraryScreen(
                onOpenBook = { bookId ->
                    navController.navigate("bookDetail/$bookId")
                }
            )
        }
        composable(Routes.EDIT) { backStack ->
            val id = backStack.arguments?.getString("userBookId") ?: ""
            EditProgressScreen(
                userBookId = id,
                onDone = { navController.popBackStack() }
            )
        }
        composable(Routes.STATS) {
            StatsScreen(onBack = { navController.popBackStack() })
        }
    }
}
