package com.example.lapelusca.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ReadingSessionDao {
    @Insert
    suspend fun insert(session: ReadingSession)

    @Query("SELECT * FROM reading_sessions WHERE bookId = :bookId")
    suspend fun sessionsFor(bookId: String): List<ReadingSession>
}
