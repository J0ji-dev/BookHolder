package com.example.lapelusca.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reading_sessions")
data class ReadingSession(
    @PrimaryKey(autoGenerate = true) val sessionId: Long = 0,
    val bookId: String,
    val minutes: Int,
    val dateUtc: Long
)
