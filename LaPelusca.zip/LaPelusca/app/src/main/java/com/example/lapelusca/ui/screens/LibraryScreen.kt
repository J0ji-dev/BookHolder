package com.example.lapelusca.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.lapelusca.ui.vm.LibraryViewModel   // <-- IMPORT CORRETO

@Composable
fun LibraryScreen(
    onOpenBook: (String) -> Unit,
    vm: LibraryViewModel = viewModel()
) {
    val items by vm.items.collectAsState()
    LaunchedEffect(Unit) { vm.load() }

    if (items.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Sua biblioteca está vazia.\nAdicione livros pela busca.")
        }
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        LazyColumn {
            items(items) { (book, userBook) ->
                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text(book.title)
                    Text("${userBook.status} (${userBook.currentPage}/${userBook.totalPages ?: 0})")
                }
                Divider()
            }
        }
    }
}
