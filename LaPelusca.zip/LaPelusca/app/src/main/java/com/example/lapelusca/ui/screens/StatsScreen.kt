package com.example.lapelusca.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.lapelusca.ui.vm.StatsViewModel

@Composable
fun StatsScreen(onBack: () -> Unit, vm: StatsViewModel = viewModel()) {
    val stats by vm.stats.collectAsState()
    LaunchedEffect(Unit) { vm.load() }

    Column(Modifier.fillMaxSize()) {
        Text("Livros lidos: ${stats.totalRead}")
        Text("Minutos lidos: ${stats.totalMinutes}")
        Button(onClick = onBack) { Text("Voltar") }
    }
}
