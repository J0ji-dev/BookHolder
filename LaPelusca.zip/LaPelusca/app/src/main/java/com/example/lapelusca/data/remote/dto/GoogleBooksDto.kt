package com.example.lapelusca.data.remote.dto

import com.squareup.moshi.Json

data class VolumeSearchResponse(
    @Json(name = "items") val items: List<VolumeItem>? = null
)

data class VolumeItem(
    @Json(name = "id") val id: String = "",
    @Json(name = "volumeInfo") val info: VolumeInfo = VolumeInfo()
)

data class VolumeInfo(
    @Json(name = "title") val title: String? = null,
    @Json(name = "authors") val authors: List<String>? = null,
    @Json(name = "imageLinks") val imageLinks: ImageLinks? = null,
    @Json(name = "pageCount") val pageCount: Int? = null
)

data class ImageLinks(
    @Json(name = "smallThumbnail") val smallThumbnail: String? = null,
    @Json(name = "thumbnail") val thumbnail: String? = null
)
