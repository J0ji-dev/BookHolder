package com.example.lapelusca.ui.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.lapelusca.data.BooksRepository
import com.example.lapelusca.data.model.Book
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SearchViewModel : ViewModel() {
    private val repo = BooksRepository()

    private val _results = MutableStateFlow<List<Book>>(emptyList())
    val results: StateFlow<List<Book>> = _results

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun search(query: String) {
        viewModelScope.launch {
            _error.value = null
            _loading.value = true
            try {
                val data = repo.searchBooks(query)
                _results.value = data
                if (data.isEmpty()) _error.value = "Nenhum resultado encontrado."
            } catch (t: Throwable) {
                _results.value = emptyList()
                _error.value = t.message ?: "Erro desconhecido"
            } finally {
                _loading.value = false
            }
        }
    }
}
