package com.example.lapelusca.data.remote

import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

data class FakePayload(
    val id: String,
    val status: String,
    val currentPage: Int
)

interface JsonPlaceholderApi {
    @POST("posts")
    suspend fun create(@Body body: FakePayload): ResponseBody

    @PUT("posts/{id}")
    suspend fun update(@Path("id") id: String, @Body body: FakePayload): ResponseBody

    @DELETE("posts/{id}")
    suspend fun delete(@Path("id") id: String): ResponseBody
}
